﻿using System.Reflection.Metadata.Ecma335;
using System.Runtime.Intrinsics.X86;
using System.Transactions;

Console.WriteLine("Welcome");
Console.WriteLine("Choose between play or shop: ");
string respond = Console.ReadLine();

while (respond != "play" && respond != "shop")
{
    Console.WriteLine("Make sure that you just type 'play' or 'shop'");
    respond = Console.ReadLine();
}
if (respond == "play")
{
    PlayGame();
    Console.WriteLine("Thank you for joining the game");
    Console.WriteLine("Do you want to go shopping? [y/n]");
    if (Console.ReadLine() == "y")
    {
        GoShopping();
        Console.WriteLine("Thank you for joining");
    }
}
else if (respond == "shop")
{
    GoShopping();
    Console.WriteLine("Thank you for joining");
    Console.WriteLine("Do you want to play game? [y/n]");
    if (Console.ReadLine() == "y")
    {
        PlayGame();
        Console.WriteLine("Thank you for joining the game");
    }
}

void PlayGame()
{
    //introduciton
    Console.WriteLine("Welcome to Beneath the Waves");
    Console.WriteLine("Here are the rules:");
    Console.WriteLine("- You will have a gun, your task is try to defeat all the hidden ships out there.");
    Console.WriteLine("- You have maximun of 25 slots");
    Console.WriteLine("- There are 4 ships with 3 sizes: one 1x3, one 1x5, two 1x2");
    Console.WriteLine("Here are the screen: ");
    string[,] gameScreen = new string[8, 8];
    BuildGrid(gameScreen);

    Console.WriteLine("Let's play");
    GameInteraction(gameScreen);
}

//hidden map
void BuildGrid(string[,] gameScreen)
{
    //Ship 1x5
    gameScreen[0, 2] = "H";  // ~~HHHHH~
    gameScreen[0, 3] = "H";  // ~~~~~~~~
    gameScreen[0, 4] = "H";  // ~H~~~~~~
    gameScreen[0, 5] = "H";  // ~H~~~HH~
    gameScreen[0, 6] = "H";  // ~H~~~~~~
                             // ~~~~~~~~
    //Ship 1x3               // ~~~HH~~~
    gameScreen[2, 1] = "H";  // ~~~~~~~~
    gameScreen[3, 1] = "H";
    gameScreen[4, 1] = "H";

    //Ship 1x2
    gameScreen[3, 5] = "H";
    gameScreen[3, 6] = "H";

    //Ship 1x2
    gameScreen[6, 3] = "H";
    gameScreen[6, 4] = "H";

    //full grid with all o and H appear
    for (int i = 0; i < gameScreen.GetLength(0); i++)
    {
        for (int j = 0; j < gameScreen.GetLength(1); j++)
        {
            if (gameScreen[i, j] != "H")
            {
                gameScreen[i, j] = "o";
            }
        }
    }

    //grid that just have ~
    for (int i = 0; i < gameScreen.GetLength(0); i++)
    {
        for (int j = 0; j < gameScreen.GetLength(1); j++)
        {
            Console.Write("~");
        }
        Console.WriteLine();
    }
}

//game organization and interaction
void GameInteraction(string[,] gameScreen)
{
    int cnt = 25;
    int hit = 0;
    int miss = 0;

    //declare new matrix
    string[,] showMap = new string[8, 8];
    for (int i = 0; i < showMap.GetLength(0); i++)
    {
        for (int j = 0; j < showMap.GetLength(1); j++)
        {
            showMap[i, j] = "~";
        }
    }

    while (cnt > 0)
    {
        Console.WriteLine("Type in the row number: ");
        int rowGuess = int.Parse(Console.ReadLine());
        Console.WriteLine("Type in the column number: ");
        int colGuess = int.Parse(Console.ReadLine());

        //counting hit and miss and slots
        if (gameScreen[rowGuess, colGuess] != "H")
        {
            miss++;
            Console.WriteLine("You make a mistake!");
        }
        else
        {
            hit++;
            Console.WriteLine("Congratulations! You hit a part of a ship.");
        }
        cnt--;
        Console.WriteLine("Hit: " + hit);
        Console.WriteLine("Miss: " + miss);
        Console.WriteLine("Left slot: " + cnt);

        for (int i = 0; i < showMap.GetLength(0); i++)
        {
            for (int j = 0; j < showMap.GetLength(1); j++)
            {
                //show previous shots
                if (i == rowGuess && j == colGuess)
                {
                    showMap[i, j] = gameScreen[i, j];
                }
            }
        }

        //show result
        for (int i = 0; i < showMap.GetLength(0); i++)
        {
            for (int j = 0; j < showMap.GetLength(1); j++)
            {
                Console.Write(showMap[i, j]);
            }
            Console.WriteLine();
        }

        if (hit == 12)
        {
            Console.WriteLine("Ships are all hitted");
            Console.WriteLine("Congratulation! You win.");
            //cnt = 0;
            return;
        }

        //reset
        Console.WriteLine("Do you want to reset? [y/n]");
        string reset = Console.ReadLine();
        if (reset == "y")
        {
            for (int i = 0; i < showMap.GetLength(0); i++)
            {
                for (int j = 0; j < showMap.GetLength(1); j++)
                {
                    showMap[i, j] = "~";
                }
            }

            //reset all the index
            cnt = 25;
            hit = 0;
            miss = 0;

            Console.WriteLine("All are reset");
        }

        Console.WriteLine("Do you want to quit? [y/n]");
        if (Console.ReadLine() == "y")
        {
            return;
        }
    }
    Console.WriteLine("Game end!");
    if (hit != 13)
    {
        Console.WriteLine("You lose");
    }
}

//Shopping game
void GoShopping()
{
    Console.WriteLine("Let's go shopping");
    Console.WriteLine("How many stores do you want to go to? ");
    int numStore = int.Parse(Console.ReadLine());

    int[][] pricesEachItem = new int[numStore][];

    for (int i = 0; i < numStore; i++)
    {
        //set cols
        Console.WriteLine("This is the " + (i + 1) + " store");
        Console.WriteLine("How many items?");
        int numItem = int.Parse(Console.ReadLine());
        int sum = 0;
        int maxPrice = -1;
        pricesEachItem[i] = new int[numItem];

        //insert item's price
        for (int j = 0; j < pricesEachItem[i].Length; j++)
        {
            Console.WriteLine("Enter the price of item " + (j + 1) + ": ");
            pricesEachItem[i][j] = int.Parse(Console.ReadLine());

            sum += pricesEachItem[i][j];
            if (pricesEachItem[i][j] > maxPrice)
            {
                maxPrice = pricesEachItem[i][j];
            }
        }

        double avg = (double)sum / numItem;

        //output of each store
        Console.WriteLine("-------------------------------------------");
        Console.WriteLine("Sum of item's prices in the store: " + sum);
        Console.WriteLine("Average: " + avg);
        Console.WriteLine("Highest price: " + maxPrice);
        Console.WriteLine("-------------------------------------------");
        Console.WriteLine();
        Console.WriteLine("Do you want to exit? [y/n]");
        if (Console.ReadLine() == "y")
        {
            return;
        }
    }
}

